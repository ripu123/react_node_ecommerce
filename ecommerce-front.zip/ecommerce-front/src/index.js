import React from "react";
import ReactDOM from "react-dom";
import Routes from "./Routes";
//import store from './store';

ReactDOM.render(<Routes />, document.getElementById("root"));