import React, { Component } from "react";
import { Link } from "react-router-dom";
import Layout from "../core/Layout";
import { API } from "../config";
import 'whatwg-fetch';
import {
    FormGroup,
    FormControl,
    HelpBlock,  
    Button,
    Alert,
} from 'react-bootstrap';
import { connect } from 'react-redux';


class SignUp extends Component {
    
    constructor() {
      super();
      this.state = {
        fields: {
        	name:'',
         	email: '',
         	show: false,
         	
         	signUpMessage: '',
         	password: ''
        },
        errors: {}
      }

      this.handleChange = this.handleChange.bind(this);
      this.submituserRegistrationForm = this.submituserRegistrationForm.bind(this);
      this.handleDismiss = this.handleDismiss.bind(this);
      //this.handleShow = this.handleShow.bind(this);
      this.displayAlert = this.displayAlert.bind(this);

    };

    handleDismiss() {
    this.setState({ show: false });
  	}

    displayAlert() {
      return (
          <Alert bsstyle={this.state.signupStatus} onClick={this.handleDismiss} id="alertBox">
              
              <p>
                { this.state.signUpMessage }
              </p>
              
            </Alert>

      );
  	}



    handleChange(e) {
      let fields = this.state.fields;
      fields[e.target.name] = e.target.value;
      this.setState({
        fields
      });

    }


    submituserRegistrationForm(e) {
      e.preventDefault();
      if (this.validateForm()) {
          let fields = {};
          fields["name"] = "";
          fields["email"] = "";
          fields["password"] = "";
          this.setState({fields:fields});
          alert("Form submitted");
		}

		const newUser = {
        password: this.state.fields.password,
        name: this.state.fields.name,
        email: this.state.fields.email,
      };

          fetch( API+"/signup", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newUser),
        })
        .then(res => res.json())
         .then(json => {
            console.log('json', json);
        
        if(json.message === "Signed Up") {
            this.setState({
                signInLoading: false,
                show: true,
                signupStatus: 'success',
                signUpMessage: 'You have signed up successfully. Proceed to login.',
                name: '',
                password: '',
                confPass: '',
                email: '',
                
            });
        } else if ( json.message === 'Error: Account Already Exists') {
            this.setState({
                signInLoading: false,
                show: true,
                signupStatus: 'warning',
                signUpMessage: 'Account already Exists. Procced to login',  
                name: '',
                password: '',
                confPass: '',
                email: '',
            });
        } else if( json.message === 'Error: Server Error') {
            this.setState({
                signInLoading: false,
                show: true,
                signupStatus: 'danger',
                signUpMessage: 'Unexpected error. Please try again later.',
                name: '',
                password: '',
                confPass: '',
                email: '',
                
            });
        }
        
            
        })
      //}

    }





    validateForm() {

      let fields = this.state.fields;
      let errors = {};
      let formIsValid = true;

      if (!fields["name"]) {
        formIsValid = false;
        errors["name"] = "*Please enter your name.";
      }

      if (typeof fields["name"] !== "undefined") {
        if (!fields["name"].match(/^[a-zA-Z ]*$/)) {
          formIsValid = false;
          errors["name"] = "*Please enter alphabet characters only.";
        }
      }

      if (!fields["email"]) {
        formIsValid = false;
        errors["email"] = "*Please enter your email-ID.";
      }

      if (typeof fields["email"] !== "undefined") {
        //regular expression for email validation
        var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
        if (!pattern.test(fields["email"])) {
          formIsValid = false;
          errors["email"] = "*Please enter valid email-ID.";
        }
      }

      if (!fields["mobileno"]) {
        formIsValid = false;
        errors["mobileno"] = "*Please enter your mobile no.";
      }

      if (typeof fields["mobileno"] !== "undefined") {
        if (!fields["mobileno"].match(/^[0-9]{10}$/)) {
          formIsValid = false;
          errors["mobileno"] = "*Please enter valid mobile no.";
        }
      }

      if (!fields["password"]) {
        formIsValid = false;
        errors["password"] = "*Please enter your password.";
      }

      if (typeof fields["password"] !== "undefined") {
        if (!fields["password"].match(/^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/)) {
          formIsValid = false;
          errors["password"] = "*Please enter secure and strong password.";
        }
      }

      this.setState({
        errors: errors,

        signUpMessage: 'You have signed up successfully. Proceed to login.',
      });
      return formIsValid;


    }


    render() {


    return (
    <div id="main-registration-container">

    	

        <Layout
            title="Signup"
            description="Signup to Node React E-commerce App"
            className="container col-md-8 offset-md-2"
        >
            
        </Layout>
   

     <div id="register">
        <h3>Registration page</h3>
        <form>
            <div className="form-group">
                <label className="text-muted">Name</label>
                <input type="text" name="name" value={this.state.fields.name} onChange={this.handleChange} className="form-control" />
                <div className="errorMsg">{this.state.errors.name}</div>
            </div>

            <div className="form-group">
                <label className="text-muted">Email</label>
                <input type="text" name="email" value={this.state.fields.email} onChange={this.handleChange} className="form-control" />
                <div className="errorMsg">{this.state.errors.email}</div>
            </div>

            <div className="form-group">
                <label className="text-muted">Password</label>
                <input type="password" name="password" value={this.state.fields.password} onChange={this.handleChange} className="form-control"/>
                <div className="errorMsg">{this.state.errors.password}</div>
            </div>
            <button  onClick = {this.state.signInLoading ? null : this.submituserRegistrationForm} className="btn btn-primary">
                Submit
            </button>
        </form>
        { this.state.show ? this.displayAlert() : null}
    </div>
</div>

      );


    
  }


    
}




export default SignUp;