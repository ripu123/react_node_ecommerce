import React, { Component } from "react";
import Layout from "../core/Layout";
import {
    FormGroup,
    FormControl,
    Button,
    Alert,
} from 'react-bootstrap';
import { API } from "../config";
import {
  setInStorage,
} from '../utils/storage';

import {map, keys} from 'lodash';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { connect } from 'react-redux';
import { loginUser } from '../actions/authentication';

class Signin extends Component{

	constructor() {
    super()
    this.state = {
      email : '',
      password: '',
      signUpMessage: '',
      errors: {}
    };
  }

  handleInputChange = (event) => {
    const { value, name } = event.target;
    this.setState({
      [name]: value
    });
  }

  displayAlert() {
      return (
          <Alert bsstyle={this.state.signupStatus} onClick={this.handleDismiss} id="alertBox">
              
              <p>
                { this.state.signUpMessage }
              </p>
              
            </Alert>

      );
  	}


  onSubmit = (event) => {
    event.preventDefault();

    const userData = {
      email: this.state.email,
      password: this.state.password
    };


    fetch( API + '/signin', {
      method: 'POST',
      body: JSON.stringify(userData),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    /*.then(res => {
      if (res.status === 200) {
        this.props.history.push('/');
      } else {
        const error = new Error(res.error);
        throw error;
        //alert("Invalid password");
      }
    })
    .catch(err => {
      console.error(err);
      alert('Error logging in please try again');
    });*/
    .then(res => res.json())
         .then(json => {
            console.log('json', json);


     if( json.message === 'Error: Incorrect email or password') {
            this.setState({
                signInLoading: false,
                show: true,
                signupStatus: 'warning',
                signUpMessage: 'Incorrect email or password. Proceed to registration.',
                password: '',
                email: '',
                
            });
        }

        else if ( json.message === 'Error: Incorrect  Password') {
            this.setState({
                signInLoading: false,
                show: true,
                signupStatus: 'warning',
                signUpMessage: 'Incorrect  Password. Procced to registration',  
                password: '',
                email: '',
            });
        }

        else if ( json.message === 'success: Valid login') {
            
                this.props.history.push('/');
            
        }  

        })
  }

  render() {
    return (
    	<div>
            <Layout title="Signin" description="Signin to Node React E-commerce App">
       
    		</Layout>

    		{ this.state.show ? this.displayAlert() : null}
      <form onSubmit={this.onSubmit}>
        <h1>Login Below!</h1>
        <input
          type="email"
          name="email"
          placeholder="Enter email"
          value={this.state.email}
          onChange={this.handleInputChange}
          className="form-control"
          required
        /><br/>
        <input
          type="password"
          name="password"
          placeholder="Enter password"
          value={this.state.password}
          onChange={this.handleInputChange}
          className="form-control"
          required
        />
        <input type="submit" value="Submit" className="btn btn-primary"/>
      </form>
      </div>
    );
  }

}





//export  default connect(mapStateToProps, { loginUser })(Signin)
export default Signin;


